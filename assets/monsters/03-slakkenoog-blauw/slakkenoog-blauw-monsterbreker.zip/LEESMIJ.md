# Blauwe Slakkenoog · Monsterbreker

Het driedimensionale model volgt de aangeleverde voor-, zij- en achteraanzichten. De romp, poten en drie oogstelen sluiten aan op één doorlopende huid. De roze ogen, koraalrode buikspiraal, knieknoppen en tenen zijn gemodelleerde vormen. De paarse vlekken en kleurvariatie zitten in vertexkleuren.

| Eigenschap | Waarde |
|---|---|
| Afmetingen GLB (breed × hoog × diep) | 1,461 × 5,000 × 1,195 m |
| Richting GLB en JSON | +Y omhoog, +Z naar voren, voeten op Y = 0 |
| Driehoeken / geëxporteerde vertices | 38.364 / 28.829 |
| Breekstukken / steunverbindingen / grondcontacten | 72 / 163 / 8 |
| Gedeelde materialen | Oppervlak en Breukvlak |
| Texturen | Vertexkleuren in de GLB |
| GLB-grootte | 1.386.868 bytes |

- slakkenoog-blauw.glb bevat de zichtbare stukken met eigen pivots. Het Blender-project bevat ook de verborgen COL_-objecten.
- breekstukken.json volgt het Gifspuwer-formaat. Colliderpunten zijn lokaal ten opzichte van de stuknode. Scoregewichten zijn genormaliseerd op basis van kernvolume en de voorbeeldwaarde voor targetFraction is overgenomen. Monsterbreker bepaalt zelf de score en spelregels.
- mouth_emit zit bij de buikspiraal voor compatibiliteit met het voorbeeldformaat.
- De vier PNG's zijn Blender-renders van dit model.

Alle stukken zijn bereikbaar vanaf de grondcontacten. Blender heeft zowel de .blend als de geëxporteerde GLB opnieuw geopend. De stuknamen komen overeen met de JSON en de meshes in de .blend hebben gesloten randen.

De ogen en spiraal bewegen mee met het stuk waaraan ze zijn toegewezen. Zulke details bestaan deels uit afzonderlijke gesloten vormen binnen een stuk. Convexe botsingsvormen benaderen het oppervlak en kunnen iets overlappen. De fijnste huidtextuur uit de referentie is vereenvoudigd. Breekgedrag en prestaties moeten nog in Monsterbreker zelf worden getest.
