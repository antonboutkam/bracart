# Bolle Stippel voor Monsterbreker

Monster-ID `04-bolle-stippelmonster`. De illustratie en de drie aangeleverde aanzichten bepalen het silhouet, de glimlach, de paarse bollen rond de kop en het stippelpatroon. De bestaande organische GLB diende als vormstudie.

| Eigenschap | Waarde |
|---|---|
| Afmetingen (breed × hoog × diep) | 3,438 × 5,000 × 2,239 m |
| Oriëntatie in GLB en JSON | +Y omhoog, +Z vooruit, voeten op Y = 0 |
| Driehoeken en geëxporteerde vertices | 39.288 en 29.626 |
| Stukken, steunverbindingen en grondcontacten | 72, 227 en 6 |
| Gedeelde materialen | Oppervlak en Breukvlak |
| Kleur | Vertexkleuren, ingebed in de GLB |
| GLB-grootte | 1.407.048 bytes |

- De GLB bevat de zichtbare stukken, eigen pivots en het anker `mouth_emit`. Het anker zit bij de glimlach en dient voor compatibiliteit met het voorbeeldformaat.
- De `.blend` bevat ook de verborgen convexe botsingsvormen als `COL_`-objecten. In `breekstukken.json` staan de punten in lokale nodecoördinaten. De scoregewichten zijn gebaseerd op het kernvolume. Monsterbreker verwerkt de score en de drempel.
- De vier PNG's zijn Blender-renders van het geleverde model. Het Python-script bevat de modelopbouw, export en renders. Reproduceer met Blender 4.3.2 via `blender -b --python maak-bolle-stippel.py -- ./uitvoer`.

De GLB en de Blend zijn opnieuw geopend in Blender. De 72 stuknamen komen overeen met de JSON. De Blender-meshes hebben gesloten randen. De steunverbindingen zijn wederzijds en maken elk stuk bereikbaar vanaf een grondcontact.

De huid en stippels zijn gestileerd. Op een paar breuknaden is een lichte overgang zichtbaar in de render. Ogen, tenen en paarse bollen bewegen mee met het stuk waaraan ze gekoppeld zijn. De botsingsvormen benaderen de geometrie. De Godot-integratie, het instorten tijdens gameplay en de framerate moeten nog in Monsterbreker worden getest.
