# Paars Stekelmonster voor Monsterbreker

Monster-ID `05-paars-stekelig-monster`. De aangeleverde illustratie en drie aanzichten bepalen het slanke silhouet, de twee amberkleurige ogen, de verzonken zigzagmond, de zes stompe zijstekels en de paarse vacht.

| Eigenschap | Waarde |
| --- | --- |
| Afmetingen (breed × hoog × diep) | 2,507 × 5,000 × 1,369 m |
| Richting in GLB en JSON | +Y omhoog, +Z naar voren, voeten op Y = 0 |
| Driehoeken en geëxporteerde vertices | 38.812 en 30.184 |
| Breekstukken, steunverbindingen en grondcontacten | 72, 193 en 4 |
| Gedeelde materialen | Oppervlak en Breukvlak |
| Kleur | Ingebedde vertexkleuren |
| GLB-grootte | 1.438.300 bytes |

De GLB bevat eigen pivots per stuk. De Blend bevat ook de verborgen COL_-objecten. De lokale punten in breekstukken.json vormen één vereenvoudigde convexe botsingsvorm per stuk. Het anker mouth_emit zit bij de mond en is beschikbaar voor compatibiliteit met het voorbeeldformaat. De scoregewichten zijn gebaseerd op het kernvolume. Monsterbreker verwerkt de score en spelregels.

De vier PNG-bestanden zijn Blender-renders van het geleverde model. Reproduceer de modelopbouw, export en renders met Blender 4.3.2 via `blender -b --python maak-stekelmonster.py -- ./uitvoer`.

De Blend en GLB zijn opnieuw geopend in Blender. Alle 72 stuknamen komen overeen met de JSON. De Blender-meshes hebben gesloten randen, de steunverbindingen zijn wederzijds en alle stukken zijn bereikbaar vanaf de grondcontacten.

De vacht bestaat uit gestileerde plukken en vertexkleurvariatie. Plukken, ogen en tenen bewegen mee met het stuk waaraan ze zijn gekoppeld. Er kan een lichte overgang zichtbaar zijn langs breuknaden. Botsingsvormen benaderen de geometrie. Breekgedrag en prestaties moeten nog in Monsterbreker worden getest.
