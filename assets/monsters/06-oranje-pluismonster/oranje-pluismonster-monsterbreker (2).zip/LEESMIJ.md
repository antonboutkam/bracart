# Oranje Pluismonster voor Monsterbreker

Monster-ID `06-oranje-pluismonster`. De aangeleverde illustratie en drie aanzichten bepalen de lange oranje romp, turquoise ogen, rechte mond, paarse onderbenen en drie tenen per voet. De vacht is opgebouwd uit gestileerde plukken en vertexkleuren.

| Eigenschap | Waarde |
| --- | --- |
| Afmetingen (breed × hoog × diep) | 1,843 × 5,000 × 1,597 m |
| Richting GLB en JSON | +Y omhoog, +Z naar voren |
| Driehoeken en geëxporteerde vertices | 39.136 en 30.564 |
| Breekstukken, steunverbindingen en grondcontacten | 72, 179 en 2 |
| Gedeelde materialen | Oppervlak en Breukvlak |
| Kleur | Ingebedde vertexkleuren |
| GLB-grootte | 1.451.200 bytes |

De laagste voet raakt Y = 0. De rechtervoet komt tot circa Y = 0,025 m en telt mee als grondcontact binnen een tolerantie van 0,030 m. Per stuk bevat de JSON één convexe botsingsvorm in lokale nodecoördinaten. De Blend bevat de bijbehorende verborgen COL_-objecten. Het anker mouth_emit zit bij de mond voor compatibiliteit met het voorbeeldformaat. Monsterbreker verwerkt de score zelf. De meegeleverde gewichten zijn gebaseerd op het kernvolume.

De vier PNG-bestanden zijn Blender-renders van het geleverde model. Reproduceer het model, de export en de renders met Blender 4.3.2 via `blender -b --python maak-pluismonster.py -- ./uitvoer`.

De Blend en GLB zijn opnieuw geopend in Blender. Alle 72 stuknamen komen overeen met de JSON. De Blender-meshes hebben gesloten randen. Steunverbindingen zijn wederzijds en verbinden elk stuk met de voeten.

Vachtplukken, ogen en tenen bewegen mee met het stuk waaraan ze zijn gekoppeld. Op enkele plekken kan een breuknaad zichtbaar zijn. De convexe botsingsvormen benaderen de geometrie. Het instorten en de prestaties moeten nog in Monsterbreker worden getest.
