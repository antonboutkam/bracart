# Gele Girafnek voor Monsterbreker

Monster-ID `07-gele-girafnek`. De aangeleverde illustratie en aanzichten bepalen de lange taps toelopende romp, afgeronde rechthoekige kop, zigzagmond, turquoise ogen en twee korte poten. De schubben zijn rondom gemodelleerd.

| Eigenschap | Waarde |
| --- | --- |
| Afmetingen breed × hoog × diep | 1,385 × 5,000 × 0,939 m |
| Oriëntatie GLB en JSON | +Y omhoog, +Z naar voren |
| Driehoeken en geëxporteerde vertices | 39.330 en 31.598 |
| Breekstukken, steunverbindingen en grondcontacten | 72, 165 en 4 |
| Gedeelde materialen | Oppervlak en Breukvlak |
| Kleur | Ingebedde vertexkleuren |
| GLB-grootte | 1.492.752 bytes |

De GLB bevat eigen pivots en het anker mouth_emit bij de mond voor compatibiliteit met het voorbeeldformaat. De Blend bevat ook verborgen COL_-objecten. Per stuk bevat de JSON één vereenvoudigde convexe botsingsvorm in lokale coördinaten. De vier grondstukken omvatten delen van de voeten en de onderste romp. De scoregewichten zijn gebaseerd op kernvolume. Monsterbreker verwerkt zelf de score en spelregels.

De vier PNG's zijn Blender-renders van het geleverde model. Reproduceer ze samen met de modelbestanden met Blender 4.3.2 via `blender -b --python maak-girafnek.py -- ./uitvoer`.

De GLB en Blend zijn opnieuw geopend in Blender. De 72 stuknamen komen overeen met de JSON. De Blender-meshes hebben gesloten randen en alle stukken zijn via wederzijdse steunverbindingen bereikbaar vanaf de grond.

De fijne huidtextuur is gestileerd. Schubben, ogen en tenen bewegen mee met hun toegewezen breekstuk. Op enkele naden kan een lichte overgang zichtbaar zijn. Instortgedrag en prestaties moeten nog in Monsterbreker worden getest.
