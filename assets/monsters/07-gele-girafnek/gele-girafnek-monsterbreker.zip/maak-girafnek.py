import bpy, math, random
from mathutils import Vector
from mathutils.noise import noise_vector
from math import sin,cos,pi
random.seed(67)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
def srgb(h):
    rgb=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(c/12.92 if c<.04045 else ((c+.055)/1.055)**2.4 for c in rgb)+(1,)
def paint(obj,h):
    m=bpy.data.materials.new(h);m.diffuse_color=srgb(h);obj.data.materials.append(m)
    return obj
def ball(name,p,s,h,segments=24,rings=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,location=p)
    o=bpy.context.object;o.name=name;o.scale=s
    for f in o.data.polygons:f.use_smooth=True
    return paint(o,h)
def box(name,p,s,r,h):
    bpy.ops.mesh.primitive_cube_add(size=2,location=p)
    o=bpy.context.object;o.name=name;o.scale=s
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    mod=o.modifiers.new('Afronding','BEVEL');mod.width=r;mod.segments=7
    bpy.ops.object.modifier_apply(modifier=mod.name)
    return paint(o,h)
def tube(name,rings,radius,h):
    points=[Vector(p) for p in rings]; n=16;vs=[];fs=[]
    for i,p in enumerate(points):
        t=(points[min(i+1,len(points)-1)]-points[max(i-1,0)]).normalized()
        a=t.cross(Vector((0,1,0))).normalized();b=t.cross(a)
        r=radius(i/(len(points)-1)) if callable(radius) else radius
        vs.extend(p+r*(cos(j*2*pi/n)*a+sin(j*2*pi/n)*b) for j in range(n))
    fs.append(tuple(reversed(range(n))))
    for i in range(len(points)-1):
        for j in range(n):
            k=(j+1)%n
            fs.append((i*n+j,i*n+k,(i+1)*n+k,(i+1)*n+j))
    fs.append(tuple(range((len(points)-1)*n,len(points)*n)))
    m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update()
    o=bpy.data.objects.new(name,m);scene.collection.objects.link(o)
    for f in m.polygons:f.use_smooth=True
    return paint(o,h)
import sys
from pathlib import Path
OUT = Path(sys.argv[sys.argv.index('--')+1]).resolve() if '--' in sys.argv else Path.cwd()
OUT.mkdir(parents=True,exist_ok=True)
random.seed(407)
skin='E7AE29'
profile=[(.30,.045,.04,0),(.34,.28,.21,0),(.45,.47,.34,0),(.65,.55,.40,0),
         (.90,.56,.42,0),(1.22,.53,.40,0),(1.64,.48,.37,0),(2.12,.43,.33,0),
         (2.65,.36,.29,0),(3.25,.29,.235,.015),(3.82,.235,.205,.024),
         (4.20,.207,.19,.034),(4.46,.205,.185,.036)]
def mix(a,b,c,d,t):
    return .5*(2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)
rings=[]
for i in range(len(profile)-1):
    a,b,c,d=[profile[max(0,min(len(profile)-1,j))] for j in range(i-1,i+3)]
    for q in range(5):
        rings.append(tuple(mix(*values,q/5) for values in zip(a,b,c,d)))
rings.append(profile[-1])
n=64
verts=[(rx*cos(j*2*pi/n),offset+ry*sin(j*2*pi/n),z) for z,rx,ry,offset in rings for j in range(n)]
faces=[tuple(reversed(range(n)))]
for i in range(len(rings)-1):
    for j in range(n):
        k=(j+1)%n
        faces.append((i*n+j,i*n+k,(i+1)*n+k,(i+1)*n+j))
faces.append(tuple(range(len(verts)-n,len(verts))))
m=bpy.data.meshes.new('Peervorm');m.from_pydata(verts,[],faces);m.update()
body=bpy.data.objects.new('Peervorm',m);scene.collection.objects.link(body)
parts=[body,box('Rechthoekige kop',(0,-.025,4.61),(.696,.355,.392),.09,skin)]
for side in (-1,1):
    parts.append(box('Poot',(side*.186,-.012,.25),(.133,.19,.272),.085,skin))
    parts.append(ball('Voet',(side*.186,-.059,.103),(.140,.223,.124),skin))
bpy.ops.object.select_all(action='DESELECT')
for obj in parts: obj.select_set(True)
bpy.context.view_layer.objects.active=body
bpy.ops.object.join()
bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
body.data.remesh_voxel_size=.025
bpy.ops.object.voxel_remesh()
mod=body.modifiers.new('Overgangen verzachten','SMOOTH');mod.factor=.78;mod.iterations=5
bpy.ops.object.modifier_apply(modifier=mod.name)
# Cut the zigzag mouth opening into the volume, with a solid back wall.
wave=[(-.55,4.63),(-.32,4.37),(-.075,4.61),(.075,4.437),(.195,4.563),(.34,4.37),(.552,4.635)]
mouth_outline=[(x,z+(.022 if 0<i<len(wave)-1 else .009)) for i,(x,z) in enumerate(wave)]
mouth_outline+=list(reversed([(x,z-(.023 if 0<i<len(wave)-1 else .009)) for i,(x,z) in enumerate(wave)]))
n=len(mouth_outline)
verts=[(x,y,z) for y in (-.65,-.276) for x,z in mouth_outline]
faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
def shape(name,verts,faces,color):
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj)
    return paint(obj,color)
cutter=shape('Mondsnede',verts,faces,'240D2C')
# Ensure outward normals on the boolean operand.
import bmesh
bm=bmesh.new();bm.from_mesh(cutter.data)
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(cutter.data);bm.free()
body.data.materials.clear();paint(body,skin)
for polygon in body.data.polygons: polygon.material_index=0
mod=body.modifiers.new('Mondopening','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cutter;mod.material_mode='TRANSFER'
bpy.ops.object.modifier_apply(modifier=mod.name)
bpy.data.objects.remove(cutter,do_unlink=True)
mod=body.modifiers.new('Vereenvoudigen','DECIMATE');mod.ratio=.105
bpy.ops.object.modifier_apply(modifier=mod.name)
for f in body.data.polygons: f.use_smooth=f.material_index==0
core=body
selected=[]
def detail(*args):
    o=ball(*args);selected.append(o);return o
for side in (-1,1):
    x=side*.205; z=4.78
    detail('Oogrand',(x,-.371,z),(.129,.054,.131),'9D641E',24,15)
    detail('Crème oog',(x,-.411,z),(.103,.069,.104),'FFEAB2',26,16)
    detail('Turquoise iris',(x+.006,-.468,z),(.073,.027,.074),'2CB9A6',24,16)
    detail('Pupil',(x+.007,-.490,z),(.044,.014,.046),'0D2731',20,13)
    detail('Ooglicht',(x-.019,-.500,z+.033),(.019,.009,.016),'FFF9E1',14,9)
    for off in (-.056,.056):
        detail('Teen',(side*.186+off,-.249,.079),(.049,.055,.066),'C79556',18,12)
from mathutils.bvhtree import BVHTree
raytree=BVHTree.FromPolygons([v.co for v in body.data.vertices],[tuple(p.vertices) for p in body.data.polygons])
def scale_tile(p,normal,width,height,color):
    up=(Vector((0,0,1))-normal*normal.z).normalized()
    side=up.cross(normal).normalized()
    # A low, overlapping shield is raised at the lower edge.
    outline=[(-.52,.21),(-.34,.48),(.34,.48),(.52,.21),(.44,-.17),(0,-.55),(-.44,-.17)]
    rim=[p+side*(x*width)+up*(y*height)+normal*(-.004-.004*abs(x)) for x,y in outline]
    verts=rim+[p+normal*.017+up*height*.02,p-normal*.026]
    faces=[(i,(i+1)%7,7) for i in range(7)]+[((i+1)%7,i,8) for i in range(7)]
    obj=shape('Schub',verts,faces,color)
    for face in obj.data.polygons: face.use_smooth=True
    selected.append(obj)
for row in range(43):
    z=.46+row*.086
    # Fewer scales fit around the neck than around the belly.
    count=max(10,round(27-15*(row/42)))
    for j in range(count):
        a=2*pi*(j+.5*(row%2))/count
        d=Vector((cos(a),sin(a),0))
        p,n,_,_=raytree.ray_cast(d*2+Vector((0,0,z)),-d)
        if p is None: continue
        olive=abs(d.y)<.60 or d.y>.05
        colors=('D4A825','DDBD38','C9A638','E1BE3C') if olive else ('F2BD33','EFB228','F7C646','E5A629')
        scale_tile(p,n,.126 if z<2 else .107,.112,random.choice(colors))
def skincolor(p):
    grain=noise_vector(p*33)[0]
    cloud=noise_vector(p*5)[1]
    shade=max(0,min(1,.55+.23*cloud+.21*grain))
    return Vector(srgb('D2961B')).lerp(Vector(srgb('FFD940')),shade)
import bpy, bmesh, json, math
from collections import Counter
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree

scene = bpy.context.scene
def bounds(points):
    pts=list(points)
    return tuple(Vector([fn(p[i] for p in pts) for i in range(3)]) for fn in (min,max))
def worldpoints(o):
    return [o.matrix_world @ v.co for v in o.data.vertices]
lo,hi=bounds(p for o in [core,*selected] for p in worldpoints(o))
origin=Vector((0,0,lo.z))
factor=5/(hi.z-lo.z)
def norm(p): return (p-origin)*factor
def gl(p): return [round(p.x,7),round(p.z,7),round(-p.y,7)]
def make_bm(o,ratio=1):
    mesh=o.data
    if ratio<1:
        tmp=bpy.data.objects.new('decimate',mesh)
        scene.collection.objects.link(tmp)
        tmp.matrix_world=o.matrix_world.copy()
        mod=tmp.modifiers.new('Simplify','DECIMATE')
        mod.ratio=ratio
        deps=bpy.context.evaluated_depsgraph_get()
        mesh=bpy.data.meshes.new_from_object(tmp.evaluated_get(deps))
        bpy.data.objects.remove(tmp,do_unlink=True)
    bm=bmesh.new()
    bm.from_mesh(mesh)
    if ratio<1: bpy.data.meshes.remove(mesh)
    for v in bm.verts: v.co=norm(o.matrix_world @ v.co)
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=0.00001)
    boundary=[e for e in bm.edges if e.is_boundary]
    if boundary: bmesh.ops.holes_fill(bm,edges=boundary,sides=0)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    return bm
def closed(bm): return len(bm.faces)>0 and all(e.is_manifold for e in bm.edges)
def cut(bm,axis,value,side):
    sub=bm.copy()
    direction=Vector([int(i==axis) for i in range(3)])
    bmesh.ops.bisect_plane(sub,geom=list(sub.verts)+list(sub.edges)+list(sub.faces),
      dist=1e-7,plane_co=direction*value,plane_no=direction,clear_inner=side,clear_outer=not side)
    edges=[e for e in sub.edges if e.is_boundary]
    if edges:
        caps=bmesh.ops.holes_fill(sub,edges=edges,sides=0)['faces']
        for f in caps: f.material_index=1; f.smooth=False
        bmesh.ops.triangulate(sub,faces=caps)
    bmesh.ops.recalc_face_normals(sub,faces=list(sub.faces))
    return sub
def split(bm,target):
    parts=[bm]
    while len(parts)<target:
        for part in sorted(parts,key=lambda b:abs(b.calc_volume()),reverse=True):
            low,high=bounds(v.co for v in part.verts)
            axes=sorted(range(3),key=lambda i:high[i]-low[i],reverse=True)
            candidate=None
            for axis in axes:
                for frac in (.49,.43,.57):
                    value=low[axis]+frac*(high[axis]-low[axis])
                    a,b=[cut(part,axis,value,s) for s in (False,True)]
                    if all(closed(k) and abs(k.calc_volume())>1e-5 for k in (a,b)) and abs(abs(a.calc_volume())+abs(b.calc_volume())-abs(part.calc_volume()))<0.0001:
                        candidate=(a,b);break
                    a.free();b.free()
                if candidate: break
            if candidate:
                parts.remove(part);part.free();parts.extend(candidate);break
        else: raise RuntimeError('Could not split further')
    return parts
def center(b): 
    low,high=bounds(v.co for v in b.verts)
    return (low+high)/2
def name_core(p):
    if p.z>4.22:return 'head'
    if p.z>2.75:return 'neck'
    if p.z<.34:return 'leg_l' if p.x<0 else 'leg_r'
    return 'body'
def color_of(o):
    mat=o.data.materials[0]
    node=next((n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED'),None) if mat.use_nodes else None
    return tuple(node.inputs['Base Color'].default_value if node else mat.diffuse_color)
def mesh_bvh(b):
    b.verts.index_update()
    return BVHTree.FromPolygons([v.co for v in b.verts],[[v.index for v in f.verts] for f in b.faces])
def snapshot(b):
    b.verts.index_update()
    return ([v.co.copy() for v in b.verts],[(tuple(v.index for v in f.verts),f.material_index,f.smooth) for f in b.faces])
def material(name):
    m=bpy.data.materials.new(name);m.use_nodes=True
    nodes=m.node_tree.nodes
    color=nodes.new('ShaderNodeVertexColor');color.layer_name='Color'
    shader=nodes.get('Principled BSDF');shader.inputs['Roughness'].default_value=.58
    m.node_tree.links.new(color.outputs['Color'],shader.inputs['Base Color'])
    return m
outer=material('Oppervlak')
inside=material('Breukvlak')
groups=[]
for o,ratio,n in [(core,1,72)]:
    bm=make_bm(o,ratio)
    assert closed(bm),o.name
    for f in bm.faces: f.material_index=2 if f.material_index else 0
    intact=bm.copy()
    intact.verts.index_update()
    source_vertices=[v.co.copy() for v in intact.verts]
    source_normals=[v.normal.copy() for v in intact.verts]
    source_faces=[tuple(v.index for v in f.verts) for f in intact.faces]
    source_bvh=mesh_bvh(intact)
    for part in split(bm,n):
        p=center(part)
        groups.append(dict(bm=part,pivot=p,prefix=name_core(p) if o==core else ('horn_l' if p.x<0 else 'horn_r'),detail=[],color=color_of(o),bvh=mesh_bvh(part)))
print('Split',len(groups),flush=True)
for o in selected:
    n=o.name
    ratio=1 if n.startswith('Schub') else .49
    bm=make_bm(o,ratio)
    if not closed(bm):
        bm.free()
        bm=make_bm(o)
    if not closed(bm):
        print('Skipped detail',n,flush=True);bm.free();continue
    p=center(bm)
    low,high=bounds(v.co for v in bm.verts)
    samples=[p]+[Vector([low[i] if (mask>>i)&1 else high[i] for i in range(3)]) for mask in range(8)]
    g=min(groups,key=lambda g:g['bvh'].find_nearest(p)[3] if n.startswith('Schub') else sum(g['bvh'].find_nearest(s)[3] for s in samples))
    g['detail'].append((bm,color_of(o)))
mouth=norm(Vector((0,-.385,4.52)))
lo2,hi2=bounds(v.co for g in groups for bm in [g['bm'],*(bm for bm,_ in g['detail'])] for v in bm.verts)
def rescale(p):
    return (p-Vector((0,0,lo2.z)))*(5/(hi2.z-lo2.z))
mouth=rescale(mouth)
for g in groups:
    for bm in [g['bm'],*(bm for bm,_ in g['detail'])]:
        for v in bm.verts: v.co=rescale(v.co)
        bm.normal_update()
    g['pivot']=rescale(g['pivot'])
    g['bvh']=mesh_bvh(g['bm'])
parent=min(groups,key=lambda g:g['bvh'].find_nearest(mouth)[3])
# Match opposing internal cut faces by sampling their interiors.
for g in groups:
    g['links']=set()
    g['bounds']=bounds(v.co for v in g['bm'].verts)
for i,g in enumerate(groups):
    for j,h in enumerate(groups[:i]):
        a,b=g['bounds'];c,d=h['bounds']
        if any(min(b[k],d[k])+1e-5<max(a[k],c[k]) for k in range(3)): continue
        found=False
        for f in g['bm'].faces:
            if f.material_index!=1 or f.calc_area()<1e-7: continue
            fc=f.calc_center_median()
            for p in [fc,*[fc.lerp(v.co,.65) for v in f.verts]]:
                if any(p[k]<c[k]-1e-5 or p[k]>d[k]+1e-5 for k in range(3)): continue
                q,normal,idx,dist=h['bvh'].find_nearest(p)
                if dist<1e-5 and normal.dot(f.normal)<-.98:
                    found=True;break
            if found: break
        if found: g['links'].add(j);h['links'].add(i)
# New scene with source geometry replaced by named pieces.
for obj in list(scene.objects): bpy.data.objects.remove(obj,do_unlink=True)
pieces=bpy.data.collections.new('Breekstukken');scene.collection.children.link(pieces)
colliders=bpy.data.collections.new('Botsingsvormen');scene.collection.children.link(colliders)
names=Counter()
for g in groups:
    names[g['prefix']]+=1;g['name']=f"{g['prefix']}_{names[g['prefix']]:03d}"
def objmesh(name,vertices,faces,collection):
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(vertices,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh);collection.objects.link(obj);return obj
rows=[]
for i,g in enumerate(groups):
    pivot=g['pivot']; pts=[];faces=[];styles=[]
    for bm,col in [(g['bm'],g['color']),*g['detail']]:
        assert closed(bm)
        vertices,polys=snapshot(bm)
        offset=len(pts);pts.extend(v-pivot for v in vertices)
        for face,mat,smooth in polys:
            faces.append([v+offset for v in face])
            styles.append((mat if bm==g['bm'] else 0,smooth,col,bm==g['bm']))
    obj=objmesh(g['name'],pts,faces,pieces);obj.location=pivot
    obj.data.materials.append(outer);obj.data.materials.append(inside)
    colors=obj.data.color_attributes.new(name='Color',type='BYTE_COLOR',domain='CORNER')
    normals=[None]*len(obj.data.loops)
    for poly,(mat,smooth,col,is_core) in zip(obj.data.polygons,styles):
        poly.material_index=int(mat==1);poly.use_smooth=smooth
        for idx in poly.loop_indices:
            p=pts[obj.data.loops[idx].vertex_index]+pivot
            colors.data[idx].color=(.31,.15,.028,1) if mat==1 else srgb('362513') if mat==2 else skincolor((p/factor)+origin) if is_core else col
            if is_core and not mat:
                _,_,fi,_=source_bvh.find_nearest(p)
                distances=[(1/max(1e-6,(p-source_vertices[j]).length),j) for j in source_faces[fi]]
                normals[idx]=sum((source_normals[j]*w for w,j in distances),Vector()).normalized()
            else:
                normals[idx]=(0,0,0)
    obj.data.normals_split_custom_set(normals)
    g['obj']=obj
    # Sample extremal directions for a small convex hull. Keep exact extents and limit vertex count.
    dirs=[Vector((x,y,z)).normalized() for x in (-1,0,1) for y in (-1,0,1) for z in (-1,0,1) if (x,y,z)!=(0,0,0)]
    hull_points={tuple(max(pts,key=lambda p:p.dot(d))) for d in dirs}
    hull=bmesh.new()
    hv=[hull.verts.new(p) for p in sorted(hull_points)]
    bmesh.ops.convex_hull(hull,input=hv,use_existing_faces=False)
    unused=[v for v in hull.verts if not v.link_faces]
    if unused: bmesh.ops.delete(hull,geom=unused,context='VERTS')
    bmesh.ops.recalc_face_normals(hull,faces=list(hull.faces))
    assert closed(hull)
    vertices,polys=snapshot(hull)
    hullobj=objmesh('COL_'+g['name'],vertices,[p[0] for p in polys],colliders)
    hullobj.parent=obj
    hullobj.hide_render=True;hullobj.hide_set(True);hullobj.display_type='WIRE'
    low,high=bounds(p+pivot for p in pts)
    volume=abs(g['bm'].calc_volume())
    rows.append(dict(id=g['name'],node=g['name'],pivot=gl(pivot),grounded=low.z<.030,volume=volume,
        neighbors=sorted(groups[j]['name'] for j in g['links']),collider=dict(type='convexHull',points=[gl(v) for v in vertices])))
anchor=bpy.data.objects.new('mouth_emit',None);pieces.objects.link(anchor)
anchor.parent=parent['obj'];anchor.location=mouth-parent['pivot'];anchor.empty_display_size=.16
scene.unit_settings.system='METRIC'
bpy.context.view_layer.update()
for g in groups: g['obj'].select_set(True)
anchor.select_set(True)
bpy.context.view_layer.objects.active=groups[0]['obj']
for c in list(scene.collection.children):
    if not c.all_objects: scene.collection.children.unlink(c)
bpy.ops.outliner.orphans_purge(do_local_ids=True,do_linked_ids=True,do_recursive=True)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'07-gele-girafnek.blend'),compress=True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'07-gele-girafnek.glb'),use_selection=True,export_yup=True,export_animations=False,export_vertex_color='ACTIVE')
total=sum(r['volume'] for r in rows)
for row in rows:
    row['scoreWeight']=row['volume']/total
    row['volume']=round(row['volume'],8)
scene_triangles=sum(len(g['obj'].data.polygons) for g in groups)
with (OUT/'breekstukken.json').open('w') as f:
    json.dump(dict(version=1,model='07-gele-girafnek.glb',up='+Y',front='+Z',units='m',targetFraction=.7,mouthEmit=dict(node='mouth_emit',parent=parent['name'],position=gl(mouth)),pieces=rows),f,indent=2)
print('Finished',len(rows),scene_triangles,'polygons',flush=True)

from mathutils import Vector
cam_data=bpy.data.cameras.new('Preview')
cam=bpy.data.objects.new('Preview',cam_data)
scene.collection.objects.link(cam)
scene.camera=cam
cam.location=(8,-13,7.5)
cam.rotation_euler=(Vector((0,0,2.4))-cam.location).to_track_quat('-Z','Y').to_euler()
cam_data.type='ORTHO';cam_data.ortho_scale=5.85
scene.render.engine='BLENDER_WORKBENCH'
sh=scene.display.shading
sh.light='STUDIO';sh.color_type='VERTEX';sh.show_shadows=False;sh.show_cavity=False
sh.background_type='WORLD'
scene.view_settings.view_transform='Standard'
scene.view_settings.exposure=.65
scene.world=bpy.data.worlds.new('Studio')
scene.world.color=(.055,.07,.10)
scene.render.resolution_x=900;scene.render.resolution_y=900;scene.render.resolution_percentage=100
for label,location in [('voor',(0,-12,2.5)),('zij',(12,0,2.5)),('achter',(0,12,2.5)),('driekwart',(6,-12,4.25))]:
    cam.location=location
    cam.rotation_euler=(Vector((0,0,2.5))-cam.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(OUT/(label+'.png'))
    bpy.ops.render.render(write_still=True)
