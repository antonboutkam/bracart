# Mini Robotmonster voor Monsterbreker

Monster-ID `08-robotmonster-mini`. Het ontwerp volgt de illustratie en aanzichten uit het bronpakket. De gouden blokvormen, gehoekte armen, donkere poten, twee lensogen en bolle buikknop zijn in 3D uitgewerkt.

| Eigenschap | Waarde |
| --- | --- |
| Afmetingen breed × hoog × diep | 5,650 × 5,000 × 1,639 m |
| Oriëntatie in GLB en JSON | +Y omhoog, +Z vooruit |
| Driehoeken en geëxporteerde vertices | 39.722 en 30.214 |
| Breekstukken, steunverbindingen en grondstukken | 72, 186 en 4 |
| Gedeelde materialen | Oppervlak en Breukvlak |
| Kleur | Ingebedde vertexkleuren |
| GLB-grootte | 1.442.064 bytes |

De GLB bevat een pivot per stuk. In de Blend staan de vereenvoudigde botsingsvormen als verborgen COL_-objecten. De JSON levert per stuk één convex hull in lokale coördinaten. Het anker mouth_emit zit bij de buikknop voor compatibiliteit met het voorbeeldformaat. De scoregewichten zijn gebaseerd op het kernvolume. Monsterbreker verwerkt de score en spelregels.

De vier PNG's zijn Blender-renders van het geleverde model. Reproduceer het model, de GLB, JSON en renders met Blender 4.3.2 via `blender -b --python maak-robotmonster.py -- ./uitvoer`.

De GLB en Blend zijn opnieuw geopend in Blender. De 72 stuknamen komen overeen met de JSON. De Blender-meshes hebben gesloten randen en alle stukken zijn via wederzijdse steunverbindingen bereikbaar vanaf de grond.

De vacht is gestileerd met korte plukken en kleurvariatie. Lensdetails en plukken bewegen mee met hun toegewezen stukken. De grondstukken zijn geselecteerd met 2,5 cm tolerantie. Botsingsvormen benaderen de geometrie en langs enkele breuknaden kan een lichte overgang zichtbaar zijn. Het instorten en de prestaties moeten nog in Monsterbreker worden getest.
