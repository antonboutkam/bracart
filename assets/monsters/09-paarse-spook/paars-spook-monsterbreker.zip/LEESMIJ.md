# Paars Spook voor Monsterbreker

Monster-ID `09-paarse-spook`. De illustratie en drie aanzichten bepalen de paarse klokvorm, roze golvende zoom, turquoise ogen en hoekige mond. De plooien en zoom lopen rondom. Het gezicht is alleen aan de voorkant gemodelleerd.

| Eigenschap | Waarde |
| --- | --- |
| Afmetingen breed × hoog × diep | 2,777 × 5,000 × 2,186 m |
| Oriëntatie in GLB en JSON | +Y omhoog, +Z vooruit |
| Driehoeken en geëxporteerde vertices | 39.198 en 30.266 |
| Breekstukken, steunverbindingen en grondstukken | 72, 223 en 4 |
| Gedeelde materialen | Oppervlak en Breukvlak |
| Kleur | Ingebedde vertexkleuren |
| GLB-grootte | 1.433.208 bytes |

Elk stuk heeft een eigen pivot en een vereenvoudigde convexe botsingsvorm in lokale coördinaten. De Blend bevat de botsingsvormen ook als verborgen COL_-objecten. Het anker mouth_emit zit bij de mond voor compatibiliteit met het voorbeeldformaat. De scoregewichten volgen het kernvolume. De spelcode verwerkt de score en spelregels.

De vier PNG's zijn renders van het geleverde model. Reproduceer de modelbestanden en renders met Blender 4.3.2 via `blender -b --python maak-paars-spook.py -- ./uitvoer`.

De Blend en GLB zijn opnieuw geopend in Blender. De 72 stuknamen komen overeen met de JSON. De Blender-meshes hebben gesloten randen. Alle stukken zijn via wederzijdse steunverbindingen bereikbaar vanaf vier grondstukken, geselecteerd binnen 3 cm van de grond.

De zachte vacht uit de referentie is gestileerd als korte plukken met kleurvariatie. De golvende zoom heeft een gesloten onderkant voor de breekstukken. Details bewegen mee met hun toegewezen breekstuk. Op sommige naden kan een lichte overgang zichtbaar zijn. Instortgedrag en prestaties moeten nog in Monsterbreker worden getest.
